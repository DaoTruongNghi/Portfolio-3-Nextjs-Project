export { default } from '../dist/local/loader'
