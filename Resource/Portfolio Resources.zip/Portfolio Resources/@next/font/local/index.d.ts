export { default } from '../dist/local/index'
