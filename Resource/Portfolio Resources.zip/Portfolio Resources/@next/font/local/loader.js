module.exports = require('../dist/local/loader')
