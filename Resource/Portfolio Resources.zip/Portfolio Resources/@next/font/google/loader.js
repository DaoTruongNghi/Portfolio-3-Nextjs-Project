module.exports = require('../dist/google/loader')
