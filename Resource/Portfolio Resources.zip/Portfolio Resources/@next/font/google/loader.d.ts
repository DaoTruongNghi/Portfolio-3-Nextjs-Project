export { default } from '../dist/google/loader'
